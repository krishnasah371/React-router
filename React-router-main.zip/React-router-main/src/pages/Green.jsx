import React from 'react'

export default function Green() {
  return (
    <div>Green</div>
  )
}