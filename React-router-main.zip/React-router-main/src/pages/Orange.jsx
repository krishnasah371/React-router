import React from 'react'

export default function Orange() {
  return (
    <div>Orange</div>
  )
}
