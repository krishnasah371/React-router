import React from 'react'

export default function Purple() {
  return (
    <div>Purple</div>
  )
}