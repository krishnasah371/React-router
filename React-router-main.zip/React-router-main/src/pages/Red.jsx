import React from 'react'

export default function Red() {
  return (
    <div>Red</div>
  )
}
